# 宝塔面板部署指南 - 智慧蜂场管理系统

## 1. 环境准备

### 1.1 服务器要求
- 操作系统：CentOS 7+ / Ubuntu 18.04+
- 宝塔面板：7.0+ 版本
- Node.js：v16+（推荐 v20）
- MySQL：5.7+ 或 MariaDB 10.3+
- Nginx：1.18+

### 1.2 软件安装
1. **安装宝塔面板**：
   - 访问 [宝塔面板官网](https://www.bt.cn/) 获取安装命令
   - 执行安装命令：`yum install -y wget && wget -O install.sh http://download.bt.cn/install/install_6.0.sh && sh install.sh`

2. **安装必要软件**：
   - 登录宝塔面板后台
   - 在「软件商店」中安装：
     - Nginx 1.18+
     - MySQL 5.7+ 或 MariaDB 10.3+
     - Node.js 管理器（安装 v20 版本）

## 2. 数据库配置

### 2.1 创建数据库和用户
1. **登录宝塔面板**，进入「数据库」管理页面
2. **创建数据库**：
   - 数据库名：`fengxiang`
   - 字符集：`utf8mb4`
   - 排序规则：`utf8mb4_unicode_ci`

3. **创建数据库用户**：
   - 用户名：`fengxiang`
   - 密码：`226886`（或根据实际情况设置）
   - 授权数据库：选择刚创建的 `fengxiang` 数据库
   - 权限：勾选「全部权限」

4. **点击「提交」** 完成数据库配置

### 2.2 验证数据库连接
1. **登录 MySQL**：
   ```bash
   mysql -u fengxiang -p
   ```
2. **输入密码**：`226886`
3. **验证连接**：
   ```sql
   SHOW DATABASES;
   USE fengxiang;
   ```
   如果能够成功执行，说明数据库配置正确。

## 3. 项目部署

### 3.1 上传文件

1. **获取部署包**：
   在项目根目录下找到 `deploy.zip` 文件（如果没有，请运行 `npm run package` 或使用提供的打包脚本生成）。

2. **创建部署目录**：
   - 在宝塔面板中，进入「文件」管理
   - 在 `/www/wwwroot/` 目录下创建 `smarthive` 文件夹

3. **上传并解压**：
   - 将 `deploy.zip` 上传到 `/www/wwwroot/smarthive/`
   - 在宝塔文件管理中解压该文件，确保文件结构如下：
     ```
     /www/wwwroot/smarthive/
     ├── dist/               # 前端静态文件
     ├── dist-server/        # 后端服务文件
     ├── package.json        # 项目配置
     ├── .env.example        # 环境变量模板
     └── README.md           # 本指南
     ```

4. **安装依赖（可选但推荐）**：
   虽然后端已经打包，但为了确保最佳兼容性，建议安装生产依赖：
   - 在宝塔终端中进入目录：`cd /www/wwwroot/smarthive`
   - 执行：`npm install --production`

### 3.2 配置环境变量
复制 `.env.example` 为 `.env` 并编辑：
- 在宝塔文件管理中，将 `.env.example` 重命名或复制为 `.env`
- 编辑 `.env` 文件，填入实际的配置信息：

```env
# 后端服务器配置
PORT=3001
API_TOKEN=2006520

# 高德地图API配置
GAODE_API_KEY=your-gaode-api-key

# MySQL数据库配置
DB_HOST=localhost
DB_USER=fengxiang
DB_PASSWORD=226886
DB_NAME=fengxiang
DB_PORT=3306

# 通义千问 (Qwen) AI API配置
QWEN_API_KEY=your-qwen-api-key
```

### 3.3 配置Nginx
1. **登录宝塔面板**，进入「网站」管理页面
2. **添加站点**：
   - 域名：输入你的域名或服务器IP
   - 根目录：`/www/wwwroot/smarthive`
   - PHP版本：纯静态

3. **配置反向代理**：
   - 进入站点设置，点击「反向代理」
   - 点击「添加反向代理」
   - 代理名称：`smarthive-api`
   - 目标URL：`http://127.0.0.1:3001`
   - 发送域名：`$host`
   - 保存设置

4. **配置Nginx规则**：
   编辑站点的Nginx配置文件，添加以下规则：

   ```nginx
   location /api {
       proxy_pass http://127.0.0.1:3001;
       proxy_set_header Host $host;
       proxy_set_header X-Real-IP $remote_addr;
       proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
       proxy_set_header X-Forwarded-Proto $scheme;
   }
   
   location / {
       try_files $uri $uri/ /index.html;
   }
   ```

### 3.4 启动后端服务
1. **安装PM2**：
   ```bash
   npm install -g pm2
   ```

2. **启动后端服务**：
   ```bash
   cd /www/wwwroot/smarthive
   pm2 start server.cjs --name smarthive-backend
   ```

3. **设置开机自启**：
   ```bash
   pm2 save
   pm2 startup
   ```

4. **查看服务状态**：
   ```bash
   pm2 status
   ```

## 4. 测试部署

### 4.1 测试后端服务
1. **访问健康检查端点**：
   ```bash
   curl http://your-domain.com/api/health
   ```
   或在浏览器中访问：`http://your-domain.com/api/health`

2. **测试API接口**：
   ```bash
   curl -H "Authorization: Bearer 2006520" http://your-domain.com/api/beehive/latest
   ```

### 4.2 测试前端页面
在浏览器中访问：`http://your-domain.com`

1. **检查页面是否正常加载**
2. **测试数据获取功能**
3. **测试视觉识别功能**
4. **测试地理编码功能**

## 5. 常见问题排查

### 5.1 数据库连接失败
**错误信息**：`Access denied for user 'fengxiang'@'localhost' (using password: YES)`

**解决方案**：
1. 检查MySQL服务是否运行：`systemctl status mysql`
2. 验证数据库用户和密码是否正确
3. 确保用户有足够的权限：
   ```sql
   GRANT ALL PRIVILEGES ON fengxiang.* TO 'fengxiang'@'localhost';
   FLUSH PRIVILEGES;
   ```

### 5.2 后端服务启动失败
**错误信息**：`Error: Cannot find module '...'`

**解决方案**：
1. 检查Node.js版本是否兼容
2. 确保所有依赖已安装：`npm install`
3. 检查文件路径是否正确

### 5.3 前端无法访问后端API
**错误信息**：`404 Not Found` 或 `CORS` 错误

**解决方案**：
1. 检查Nginx反向代理配置是否正确
2. 检查后端服务是否正在运行：`pm2 status`
3. 检查API路径是否正确

### 5.4 端口被占用
**错误信息**：`EADDRINUSE: address already in use`

**解决方案**：
1. 查找占用端口的进程：`lsof -i :3001`
2. 终止占用端口的进程：`kill -9 <PID>`
3. 重新启动后端服务：`pm2 restart smarthive-backend`

## 6. 维护与更新

### 6.1 查看日志
```bash
pm logs smarthive-backend
```

### 6.2 重启服务
```bash
pm restart smarthive-backend
```

### 6.3 更新代码
1. 本地修改代码
2. 重新构建：`npm run build && npm run build:server`
3. 上传更新后的文件到服务器
4. 重启服务：`pm2 restart smarthive-backend`

## 7. 安全建议

1. **修改API_TOKEN**：使用更长的随机字符串
2. **设置HTTPS**：在宝塔面板中配置SSL证书
3. **限制访问**：配置防火墙，只允许必要的端口
4. **定期备份**：定期备份数据库和配置文件
5. **更新依赖**：定期更新项目依赖，修复安全漏洞

---

**部署完成后**，你可以通过 `http://your-domain.com` 访问智慧蜂场管理系统的前端页面，后端API通过 `http://your-domain.com/api` 访问。

如果遇到任何问题，请参考「常见问题排查」部分，或联系技术支持。